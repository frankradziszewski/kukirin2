package com.kukirin.client;

import com.kukirin.KuKirinClientMod;
import com.kukirin.KuKirinMod;
import com.kukirin.entity.KuKirinEntity;
import com.kukirin.entity.ModEntities;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

public class KuKirinEntityRenderer extends EntityRenderer<KuKirinEntity> {
	private static final Identifier TEX_G2 = Identifier.of(KuKirinMod.MOD_ID, "textures/entity/kukirin_g2_pro.png");
	private static final Identifier TEX_G4 = Identifier.of(KuKirinMod.MOD_ID, "textures/entity/kukirin_g4_ultra_max.png");

	private final KuKirinModel model;

	public KuKirinEntityRenderer(EntityRendererFactory.Context ctx) {
		super(ctx);
		this.model = new KuKirinModel(ctx.getPart(KuKirinClientMod.SCOOTER_LAYER));
		this.shadowRadius = 0.5f;
	}

	@Override
	public Identifier getTexture(KuKirinEntity entity) {
		return entity.getType() == ModEntities.G4 ? TEX_G4 : TEX_G2;
	}

	@Override
	public void render(KuKirinEntity entity, float yaw, float tickDelta, MatrixStack matrices,
					   VertexConsumerProvider vertexConsumers, int light) {
		matrices.push();

		matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - yaw));

		// WHEELIE: obrót wokół osi tylnego koła (pitch -30° => przód w górę)
		float pitch = MathHelper.lerp(tickDelta, entity.prevPitch, entity.getPitch());
		matrices.translate(0.0, KuKirinEntity.AXLE_HEIGHT, KuKirinEntity.AXLE_BACK);
		matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-pitch));
		matrices.translate(0.0, -KuKirinEntity.AXLE_HEIGHT, -KuKirinEntity.AXLE_BACK);

		matrices.scale(-1.0f, -1.0f, 1.0f);
		matrices.translate(0.0f, -1.501f, 0.0f);

		model.setWheelAngle(entity.getWheelAngle(tickDelta));
		VertexConsumer consumer = vertexConsumers.getBuffer(model.getLayer(getTexture(entity)));
		model.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV, -1);

		matrices.pop();
		super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
	}
}
