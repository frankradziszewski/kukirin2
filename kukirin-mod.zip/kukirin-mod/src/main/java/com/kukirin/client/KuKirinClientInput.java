package com.kukirin.client;

import com.kukirin.entity.KuKirinEntity;
import com.kukirin.network.KuKirinInputPayload;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Sterowanie i HUD:
 *  W/S = gaz/hamulec, A/D = skręt, SPACJA (trzymana) = wheelie,
 *  NITRO = podwójne kliknięcie W (przytrzymaj drugie) LUB klawisz "Nitro Boost" (domyślnie Lewy Ctrl),
 *  H = klakson.
 *
 *  Uwaga: Shift w Minecraftcie zsiada z pojazdu, więc nitro nie może być na Shift bez konfliktu
 *  (w ustawieniach sterowania można przypisać dowolny inny klawisz).
 */
public final class KuKirinClientInput {
	private static KeyBinding nitroKey;
	private static KeyBinding hornKey;

	private static int tick;
	private static int lastWPress = -100;
	private static boolean wasW;
	private static boolean doubleTapNitro;

	private static boolean sentWheelie, sentNitro, sentHorn;

	public static void init() {
		nitroKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.kukirin.nitro", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_CONTROL, "key.categories.kukirin"));
		hornKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.kukirin.horn", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_H, "key.categories.kukirin"));

		ClientTickEvents.END_CLIENT_TICK.register(KuKirinClientInput::onTick);
		HudRenderCallback.EVENT.register(KuKirinClientInput::renderHud);
	}

	private static void onTick(MinecraftClient mc) {
		tick++;
		if (mc.player == null || !(mc.player.getVehicle() instanceof KuKirinEntity scooter)) {
			wasW = false; doubleTapNitro = false;
			sentWheelie = sentNitro = sentHorn = false;
			return;
		}

		GameOptions o = mc.options;
		boolean w = o.forwardKey.isPressed();
		if (w && !wasW) {
			if (tick - lastWPress <= 7) doubleTapNitro = true;   // podwójne kliknięcie W
			lastWPress = tick;
		}
		if (!w) doubleTapNitro = false;
		wasW = w;

		float forward = (w ? 1f : 0f) - (o.backKey.isPressed() ? 1f : 0f);
		float side = (o.leftKey.isPressed() ? 1f : 0f) - (o.rightKey.isPressed() ? 1f : 0f);
		boolean wheelie = o.jumpKey.isPressed();
		boolean nitro = nitroKey.isPressed() || doubleTapNitro;
		boolean horn = hornKey.isPressed();

		scooter.setClientInput(forward, side, wheelie, nitro);

		float crash = scooter.pollCrashSpeed();
		if (crash > 0f || wheelie != sentWheelie || nitro != sentNitro || horn != sentHorn) {
			ClientPlayNetworking.send(new KuKirinInputPayload(wheelie, nitro, horn, crash));
			sentWheelie = wheelie; sentNitro = nitro; sentHorn = horn;
		}
	}

	private static void renderHud(net.minecraft.client.gui.DrawContext ctx, net.minecraft.client.render.RenderTickCounter counter) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden || !(mc.player.getVehicle() instanceof KuKirinEntity s)) return;

		int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
		int kmh = (int) Math.round(s.getSpeed() * 72.0);      // bloki/tick * 20 * 3.6
		ctx.drawCenteredTextWithShadow(mc.textRenderer, kmh + " km/h", w / 2, h - 72, s.isNitroActive() ? 0xFFAA00 : 0xFFFFFF);

		int bw = 90, x = w / 2 - bw / 2, y = h - 62;
		int filled = (int) (bw * (s.getNitroCharge() / (float) KuKirinEntity.MAX_NITRO));
		ctx.fill(x - 1, y - 1, x + bw + 1, y + 6, 0xAA000000);
		ctx.fill(x, y, x + filled, y + 5, s.isNitroActive() ? 0xFFFF7A00 : 0xFF00C8FF);
		ctx.drawCenteredTextWithShadow(mc.textRenderer, "NITRO", w / 2, y - 10, 0xAAAAAA);
	}

	private KuKirinClientInput() {}
}
