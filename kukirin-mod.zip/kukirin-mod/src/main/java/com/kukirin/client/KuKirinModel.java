package com.kukirin.client;

import com.kukirin.entity.KuKirinEntity;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.util.math.MatrixStack;

/**
 * Model hulajnogi zbudowany w kodzie (bez pliku .bbmodel). Przód = -Z, ziemia = y 24 (konwencja modeli MC).
 * Tekstura 64x64: pasy kolorów - rama (v0), deska (v16), akcent (v32), koła (v48).
 */
public class KuKirinModel extends EntityModel<KuKirinEntity> {
	private final ModelPart root;
	private final ModelPart frontWheel;
	private final ModelPart rearWheel;

	public KuKirinModel(ModelPart root) {
		this.root = root;
		this.frontWheel = root.getChild("front_wheel");
		this.rearWheel = root.getChild("rear_wheel");
	}

	public static TexturedModelData getTexturedModelData() {
		ModelData data = new ModelData();
		ModelPartData r = data.getRoot();

		// deska + akumulator pod deską + błotnik
		r.addChild("deck", ModelPartBuilder.create().uv(0, 16).cuboid(-3, 15, -6, 6, 2, 13), ModelTransform.NONE);
		r.addChild("battery", ModelPartBuilder.create().uv(0, 32).cuboid(-2, 17, -4, 4, 2, 9), ModelTransform.NONE);
		r.addChild("fender", ModelPartBuilder.create().uv(0, 32).cuboid(-2, 14, 7, 4, 1, 9), ModelTransform.NONE);

		// widelec, szyjka, kierownica, lampa
		r.addChild("fork_l", ModelPartBuilder.create().uv(0, 0).cuboid(-2, 8, -11, 1, 13, 2), ModelTransform.NONE);
		r.addChild("fork_r", ModelPartBuilder.create().uv(0, 0).cuboid(1, 8, -11, 1, 13, 2), ModelTransform.NONE);
		r.addChild("neck", ModelPartBuilder.create().uv(0, 0).cuboid(-1, 9, -9, 2, 6, 3), ModelTransform.NONE);
		r.addChild("handlebar", ModelPartBuilder.create().uv(0, 0).cuboid(-6, 6, -11, 12, 2, 2), ModelTransform.NONE);
		r.addChild("grips", ModelPartBuilder.create().uv(0, 48).cuboid(-8, 6, -11, 2, 2, 2).cuboid(6, 6, -11, 2, 2, 2), ModelTransform.NONE);
		r.addChild("headlight", ModelPartBuilder.create().uv(0, 32).cuboid(-1.5f, 9, -12, 3, 3, 1), ModelTransform.NONE);

		// koła: dwa sześciany obrócone o 45° dają ośmiokąt; pivot w osi koła, żeby dało się je kręcić
		addWheel(r, "front_wheel", -10);
		addWheel(r, "rear_wheel", 11);

		return TexturedModelData.of(data, 64, 64);
	}

	private static void addWheel(ModelPartData root, String name, float z) {
		ModelPartData wheel = root.addChild(name,
				ModelPartBuilder.create().uv(0, 48).cuboid(-1, -4, -4, 2, 8, 8),
				ModelTransform.pivot(0, 20, z));
		wheel.addChild(name + "_octagon",
				ModelPartBuilder.create().uv(0, 48).cuboid(-0.9f, -4, -4, 1.8f, 8, 8),
				ModelTransform.rotation((float) (Math.PI / 4), 0, 0));
	}

	public void setWheelAngle(float angle) {
		frontWheel.pitch = angle;
		rearWheel.pitch = angle;
	}

	@Override
	public void setAngles(KuKirinEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
		// animacja jest ustawiana w rendererze przez setWheelAngle()
	}

	@Override
	public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay, int color) {
		root.render(matrices, vertices, light, overlay, color);
	}
}
