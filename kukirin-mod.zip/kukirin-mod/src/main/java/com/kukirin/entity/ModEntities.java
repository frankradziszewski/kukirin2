package com.kukirin.entity;

import com.kukirin.KuKirinMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

@SuppressWarnings("deprecation")
public final class ModEntities {
	public static final EntityType<KuKirinEntity> G2 = register("kukirin_g2_pro");
	public static final EntityType<KuKirinEntity> G4 = register("kukirin_g4_ultra_max");

	private static EntityType<KuKirinEntity> register(String name) {
		EntityType<KuKirinEntity> type = FabricEntityTypeBuilder
				.<KuKirinEntity>create(SpawnGroup.MISC, KuKirinEntity::new)
				.dimensions(EntityDimensions.fixed(0.8f, 1.0f))
				.trackRangeBlocks(96)
				.trackedUpdateRate(1)
				.forceTrackedVelocityUpdates(true)
				.build();
		return Registry.register(Registries.ENTITY_TYPE, Identifier.of(KuKirinMod.MOD_ID, name), type);
	}

	public static void init() {}

	private ModEntities() {}
}
