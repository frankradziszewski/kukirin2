package com.kukirin.entity;

import com.kukirin.item.ModItems;
import com.kukirin.network.KuKirinInputPayload;
import com.kukirin.sound.ModSounds;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Elektryczna hulajnoga KuKirin (G2 Pro / G4 Ultra Max).
 *
 * Architektura jak w łodzi: ruch liczy KLIENT kierowcy (isLogicalSideForUpdatingMovement), a serwer
 * dostaje pozycję przez VehicleMoveC2SPacket. Stan, którego serwer musi pilnować (nitro, klakson,
 * zderzenia), leci osobnym pakietem KuKirinInputPayload.
 */
public class KuKirinEntity extends Entity {

	// ------------------------------------------------------------------ warianty
	public enum Variant {
		//          max blocks/tick, przyspieszenie, hamowanie, skręt (°/tick)
		G2(0.65, 0.022, 0.060, 5.5f),   // ~45-47 km/h
		G4(1.25, 0.038, 0.090, 5.0f);   // ~85-90 km/h (3000 W / 72 V)

		public final double maxSpeed, accel, brake;
		public final float turn;

		Variant(double maxSpeed, double accel, double brake, float turn) {
			this.maxSpeed = maxSpeed; this.accel = accel; this.brake = brake; this.turn = turn;
		}
	}

	public static final int MAX_NITRO = 200;               // 200 ticków = 10 s nitro
	public static final float WHEELIE_PITCH = -30f;        // ujemny pitch = przód w górę
	public static final double NITRO_MULTIPLIER = 1.30;    // +30%

	// geometria (w blokach) zgodna z modelem: oś tylnego koła i wysokość deski
	public static final double AXLE_BACK = 0.6875;
	public static final double AXLE_HEIGHT = 0.25;
	private static final double DECK_HEIGHT = 0.5625;
	private static final double RIDER_FORWARD = -0.05;

	private static final TrackedData<Integer> NITRO_CHARGE =
			DataTracker.registerData(KuKirinEntity.class, TrackedDataHandlerRegistry.INTEGER);
	private static final TrackedData<Boolean> NITRO_ACTIVE =
			DataTracker.registerData(KuKirinEntity.class, TrackedDataHandlerRegistry.BOOLEAN);

	// ---- wejście lokalnego gracza (ustawiane przez klienta, nie synchronizowane)
	private float inForward, inSide;
	private boolean inWheelie, inNitro;
	private float pendingCrash;

	// ---- stan serwera
	private int hornCooldown;

	// ---- interpolacja dla obserwatorów (jak w łodzi)
	private int lerpTicks;
	private double lerpX, lerpY, lerpZ, lerpYaw, lerpPitch;

	// ---- stan kliencki / wizualny
	private double speed;          // bloki/tick (poziomo)
	private double signedSpeed;    // ze znakiem względem kierunku jazdy
	private float wheelAngle, prevWheelAngle;
	private float lastPassengerYaw;
	private double lastSoundSpeed;

	public KuKirinEntity(EntityType<? extends KuKirinEntity> type, World world) {
		super(type, world);
	}

	public Variant variant() {
		return getType() == ModEntities.G4 ? Variant.G4 : Variant.G2;
	}

	public Item asItem() {
		return getType() == ModEntities.G4 ? ModItems.G4 : ModItems.G2;
	}

	// ------------------------------------------------------------------ dane
	@Override
	protected void initDataTracker(DataTracker.Builder builder) {
		builder.add(NITRO_CHARGE, MAX_NITRO);
		builder.add(NITRO_ACTIVE, false);
	}

	@Override
	protected void readCustomDataFromNbt(NbtCompound nbt) {
		if (nbt.contains("NitroCharge")) dataTracker.set(NITRO_CHARGE, MathHelper.clamp(nbt.getInt("NitroCharge"), 0, MAX_NITRO));
	}

	@Override
	protected void writeCustomDataToNbt(NbtCompound nbt) {
		nbt.putInt("NitroCharge", getNitroCharge());
	}

	public int getNitroCharge() { return dataTracker.get(NITRO_CHARGE); }
	public boolean isNitroActive() { return dataTracker.get(NITRO_ACTIVE); }
	public boolean isWheelieing() { return getPitch() < -12f; }
	public double getSpeed() { return speed; }
	public float getWheelAngle(float tickDelta) { return MathHelper.lerp(tickDelta, prevWheelAngle, wheelAngle); }

	/** Easy Boost: natychmiast pełny zbiornik nitro. */
	public void chargeNitro() {
		dataTracker.set(NITRO_CHARGE, MAX_NITRO);
	}

	// ------------------------------------------------------------------ interakcja
	@Override
	public ActionResult interact(PlayerEntity player, Hand hand) {
		if (player.isSneaking()) return ActionResult.PASS;   // Shift + PPM = nie wsiadaj
		if (getWorld().isClient) return ActionResult.SUCCESS;
		return player.startRiding(this) ? ActionResult.CONSUME : ActionResult.PASS;
	}

	@Override
	protected boolean canAddPassenger(Entity passenger) {
		return getPassengerList().isEmpty();
	}

	@Nullable
	@Override
	public LivingEntity getControllingPassenger() {
		return getFirstPassenger() instanceof LivingEntity living ? living : null;
	}

	@Override
	public boolean canHit() {
		return !isRemoved();
	}

	@Override
	public ItemStack getPickBlockStack() {
		return new ItemStack(asItem());
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		if (isInvulnerableTo(source)) return false;
		if (getWorld().isClient || isRemoved()) return true;
		if (source.getAttacker() instanceof PlayerEntity attacker) {
			if (!attacker.isCreative()) dropStack(new ItemStack(asItem()));
			discard();
			return true;
		}
		return false;
	}

	// Poniższe metody celowo bez @Override - sygnatury bywają różne między buildami mappingów,
	// a brak dopasowania nie psuje kompilacji (zachowanie fallback jest bezpieczne).
	public boolean shouldRiderSit() {
		return false; // gracz stoi na desce
	}

	public float getStepHeight() {
		return 1.0f; // wjeżdża na pełne bloki
	}

	public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int interpolationSteps) {
		lerpX = x; lerpY = y; lerpZ = z; lerpYaw = yaw; lerpPitch = pitch;
		lerpTicks = 10;
	}

	public void updatePassengerPosition(Entity passenger, Entity.PositionUpdater updater) {
		if (!hasPassenger(passenger)) return;
		float yawRad = getYaw() * MathHelper.RADIANS_PER_DEGREE;
		double fx = -MathHelper.sin(yawRad), fz = MathHelper.cos(yawRad);

		// pozycja kierowcy obrócona wokół osi tylnego koła (przy wheelie gracz unosi się razem z deską)
		double theta = -getPitch() * MathHelper.RADIANS_PER_DEGREE;
		double f = RIDER_FORWARD + AXLE_BACK;
		double u = DECK_HEIGHT - AXLE_HEIGHT;
		double f2 = f * Math.cos(theta) - u * Math.sin(theta);
		double u2 = f * Math.sin(theta) + u * Math.cos(theta);
		double forward = -AXLE_BACK + f2;
		double height = AXLE_HEIGHT + u2;

		updater.accept(passenger, getX() + fx * forward, getY() + height, getZ() + fz * forward);

		if (passenger instanceof LivingEntity living) living.bodyYaw = getYaw();
		if (getWorld().isClient && isLogicalSideForUpdatingMovement()) {
			// kamera obraca się razem z hulajnogą
			float d = MathHelper.wrapDegrees(getYaw() - lastPassengerYaw);
			lastPassengerYaw = getYaw();
			passenger.setYaw(passenger.getYaw() + d);
			passenger.setHeadYaw(passenger.getHeadYaw() + d);
		}
	}

	// ------------------------------------------------------------------ wejście klienta
	/** Wywoływane wyłącznie przez klienta lokalnego gracza. */
	public void setClientInput(float forward, float side, boolean wheelie, boolean nitro) {
		this.inForward = forward; this.inSide = side; this.inWheelie = wheelie; this.inNitro = nitro;
	}

	public float pollCrashSpeed() {
		float c = pendingCrash; pendingCrash = 0f; return c;
	}

	// ------------------------------------------------------------------ serwer: pakiet wejścia
	public void applyClientInput(KuKirinInputPayload p, ServerPlayerEntity rider) {
		boolean shouldBoost = p.nitro() && getNitroCharge() > 10;
		if (shouldBoost != isNitroActive()) {
			dataTracker.set(NITRO_ACTIVE, shouldBoost);
			if (shouldBoost) {
				getWorld().playSound(null, getX(), getY(), getZ(), ModSounds.NITRO, SoundCategory.NEUTRAL, 1.0f, 1.0f);
			}
		}
		if (p.horn() && hornCooldown <= 0) {
			hornCooldown = 12;
			getWorld().playSound(null, getX(), getY(), getZ(), ModSounds.HORN, SoundCategory.NEUTRAL, 2.5f, variant() == Variant.G4 ? 0.85f : 1.05f);
		}
		float crash = Math.min(p.crashSpeed(), 3.0f);
		if (crash > 0.55f) handleCrash(rider, crash);
	}

	private void handleCrash(ServerPlayerEntity rider, float s) {
		if (!(getWorld() instanceof ServerWorld sw)) return;
		sw.playSound(null, getX(), getY(), getZ(), SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.NEUTRAL, 0.7f, 1.5f);
		sw.spawnParticles(ParticleTypes.CRIT, getX(), getY() + 0.6, getZ(), 24, 0.35, 0.35, 0.35, 0.4);
		sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.5, getZ(), 16, 0.3, 0.3, 0.3, 0.5);

		float dmg = (s - 0.55f) * 25f;
		ItemStack helmet = rider.getEquippedStack(EquipmentSlot.HEAD);
		if (helmet.isOf(ModItems.HELMET)) {
			helmet.damage(Math.max(1, (int) (dmg / 3f)), rider, EquipmentSlot.HEAD); // kask przyjmuje uderzenie
		} else {
			rider.damage(rider.getDamageSources().flyIntoWall(), dmg);
		}
		if (s > 0.9f) { // mocne uderzenie = wyrzuca kierowcę
			float yawRad = getYaw() * MathHelper.RADIANS_PER_DEGREE;
			rider.stopRiding();
			rider.setVelocity(-MathHelper.sin(yawRad) * s * 0.6, 0.4, MathHelper.cos(yawRad) * s * 0.6);
			rider.velocityModified = true;
		}
	}

	// ------------------------------------------------------------------ tick
	@Override
	public void tick() {
		super.tick();
		tickLerp();

		if (!getWorld().isClient) serverTick();

		if (isLogicalSideForUpdatingMovement()) {
			driveTick();
		} else {
			setVelocity(Vec3d.ZERO);
		}

		if (!hasPassengers()) lastPassengerYaw = getYaw();

		// prędkość zmierzona z realnego przesunięcia (działa u wszystkich obserwatorów)
		double dx = getX() - prevX, dz = getZ() - prevZ;
		speed = Math.sqrt(dx * dx + dz * dz);
		float yawRad = getYaw() * MathHelper.RADIANS_PER_DEGREE;
		signedSpeed = (dx * -MathHelper.sin(yawRad) + dz * MathHelper.cos(yawRad)) >= 0 ? speed : -speed;
		prevWheelAngle = wheelAngle;
		wheelAngle += (float) (signedSpeed * 4.0); // promień koła 0.25 => 4 rad na blok

		if (getWorld().isClient) clientEffects();
	}

	private void serverTick() {
		if (hornCooldown > 0) hornCooldown--;
		if (!hasPassengers() && isNitroActive()) dataTracker.set(NITRO_ACTIVE, false);

		int charge = getNitroCharge();
		if (isNitroActive()) {
			charge--;
			if (charge <= 0) { charge = 0; dataTracker.set(NITRO_ACTIVE, false); }
			dataTracker.set(NITRO_CHARGE, charge);
		} else if (charge < MAX_NITRO && age % 4 == 0) {
			dataTracker.set(NITRO_CHARGE, charge + 1); // powolna regeneracja
		}
	}

	private void tickLerp() {
		if (isLogicalSideForUpdatingMovement()) {
			lerpTicks = 0;
			updateTrackedPosition(getX(), getY(), getZ());
		}
		if (lerpTicks <= 0) return;
		double nx = getX() + (lerpX - getX()) / lerpTicks;
		double ny = getY() + (lerpY - getY()) / lerpTicks;
		double nz = getZ() + (lerpZ - getZ()) / lerpTicks;
		float yaw = getYaw() + (float) MathHelper.wrapDegrees(lerpYaw - getYaw()) / lerpTicks;
		float pitch = getPitch() + (float) (lerpPitch - getPitch()) / lerpTicks;
		lerpTicks--;
		setPosition(nx, ny, nz);
		setRotation(yaw, pitch);
	}

	/** Fizyka - wykonywana po stronie kierowcy (klient) lub serwera, gdy nikt nie jedzie. */
	private void driveTick() {
		boolean driven = getControllingPassenger() != null;
		if (!driven) { inForward = 0; inSide = 0; inWheelie = false; inNitro = false; }

		Variant v = variant();
		boolean boost = driven && isNitroActive();
		double max = v.maxSpeed * (boost ? NITRO_MULTIPLIER : 1.0);

		float yawRad = getYaw() * MathHelper.RADIANS_PER_DEGREE;
		double fx = -MathHelper.sin(yawRad), fz = MathHelper.cos(yawRad);
		Vec3d vel = getVelocity();
		double fs = vel.x * fx + vel.z * fz;               // prędkość wzdłuż osi hulajnogi

		if (inForward > 0) {
			fs += v.accel * (boost ? 1.8 : 1.0);
		} else if (inForward < 0) {
			fs -= (fs > 0.02 ? v.brake : v.accel * 0.5);
		} else {
			fs *= 0.985;                                    // wybieg
			if (Math.abs(fs) < 0.004) fs = 0;
		}
		if (!isOnGround()) fs *= 0.998;
		if (fs > max) fs = Math.max(max, fs - 0.02);        // po nitro łagodnie wracamy do normalnej prędkości
		fs = Math.max(fs, -v.maxSpeed * 0.2);
		if (isTouchingWater()) fs *= 0.9;

		// skręt: mniejszy przy dużej prędkości i w wheelie
		if (Math.abs(fs) > 0.01 && inSide != 0) {
			double ratio = Math.min(1.0, Math.abs(fs) / v.maxSpeed);
			float turn = (float) (v.turn * (1.0 - 0.6 * ratio)) * inSide * (isWheelieing() ? 0.6f : 1f);
			setYaw(getYaw() - (fs >= 0 ? turn : -turn));   // A (inSide=+1) = w lewo = yaw maleje
			yawRad = getYaw() * MathHelper.RADIANS_PER_DEGREE;
			fx = -MathHelper.sin(yawRad); fz = MathHelper.cos(yawRad);
		}

		// WHEELIE: przytrzymana spacja + jazda po ziemi => przód w górę (pitch -30°)
		boolean wheelie = driven && inWheelie && isOnGround() && Math.abs(fs) > 0.12;
		float target = wheelie ? WHEELIE_PITCH : 0f;
		float p = getPitch();
		p += (target - p) * 0.3f;
		if (Math.abs(p - target) < 0.5f) p = target;
		setPitch(p);

		double vy = (vel.y - 0.08) * 0.98;
		setVelocity(fx * fs, vy, fz * fs);
		double pre = Math.abs(fs);
		move(MovementType.SELF, getVelocity());

		// wykrycie zderzenia: uderzyliśmy w przeszkodę i wytraciliśmy większość prędkości
		Vec3d after = getVelocity();
		double post = Math.sqrt(after.x * after.x + after.z * after.z);
		if (driven && horizontalCollision && pre > 0.55 && post < pre * 0.45) {
			pendingCrash = (float) pre;
			setVelocity(0, after.y, 0);
		}
	}

	// ------------------------------------------------------------------ efekty (klient)
	private void clientEffects() {
		World w = getWorld();
		float yawRad = getYaw() * MathHelper.RADIANS_PER_DEGREE;
		double fx = -MathHelper.sin(yawRad), fz = MathHelper.cos(yawRad);
		Variant v = variant();
		boolean nitro = isNitroActive() && speed > 0.05;

		// dźwięk silnika: głośniej i wyżej przy przyspieszaniu
		if (hasPassengers() && speed > 0.05 && age % 8 == 0) {
			boolean accelerating = speed - lastSoundSpeed > 0.01;
			lastSoundSpeed = speed;
			float pitch = (float) (0.7 + 0.9 * Math.min(1.3, speed / v.maxSpeed)) + (nitro ? 0.15f : 0f);
			w.playSound(getX(), getY(), getZ(), ModSounds.ENGINE, SoundCategory.NEUTRAL, accelerating ? 0.7f : 0.3f, pitch, false);
		}

		// WHEELIE: iskry spod tylnego koła
		if (isWheelieing() && speed > 0.05) {
			double bx = getX() - fx * AXLE_BACK, bz = getZ() - fz * AXLE_BACK, by = getY() + 0.05;
			for (int i = 0; i < 3; i++) {
				double rx = (random.nextDouble() - 0.5) * 0.2, rz = (random.nextDouble() - 0.5) * 0.2;
				w.addParticle(ParticleTypes.ELECTRIC_SPARK, bx + rx, by, bz + rz,
						-fx * 0.25 + rx, 0.12 + random.nextDouble() * 0.15, -fz * 0.25 + rz);
			}
			w.addParticle(ParticleTypes.CRIT, bx, by, bz, -fx * 0.3, 0.2, -fz * 0.3);
			if (random.nextInt(3) == 0) w.addParticle(ParticleTypes.FLAME, bx, by, bz, -fx * 0.1, 0.05, -fz * 0.1);
		}

		// NITRO: płomienie z wydechu
		if (nitro) {
			double ex = getX() - fx * 0.85, ez = getZ() - fz * 0.85, ey = getY() + 0.35;
			for (int i = 0; i < 4; i++) {
				w.addParticle(ParticleTypes.FLAME, ex, ey, ez,
						-fx * (0.25 + random.nextDouble() * 0.2) + (random.nextDouble() - 0.5) * 0.06,
						0.01 + random.nextDouble() * 0.04,
						-fz * (0.25 + random.nextDouble() * 0.2) + (random.nextDouble() - 0.5) * 0.06);
			}
			w.addParticle(ParticleTypes.SMALL_FLAME, ex, ey, ez, -fx * 0.4, 0.02, -fz * 0.4);
			if (age % 2 == 0) w.addParticle(ParticleTypes.SMOKE, ex, ey, ez, -fx * 0.1, 0.03, -fz * 0.1);
		}
	}
}
