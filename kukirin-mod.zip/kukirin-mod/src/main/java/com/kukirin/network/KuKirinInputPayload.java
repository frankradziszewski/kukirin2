package com.kukirin.network;

import com.kukirin.KuKirinMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/**
 * Klient -> serwer. Wysyłany przy zmianie stanu klawiszy oraz jednorazowo przy zderzeniu.
 * (Ruch hulajnogi liczy klient - jak łódź - a serwer dostaje go standardowym pakietem VehicleMove.)
 */
public record KuKirinInputPayload(boolean wheelie, boolean nitro, boolean horn, float crashSpeed) implements CustomPayload {
	public static final CustomPayload.Id<KuKirinInputPayload> ID =
			new CustomPayload.Id<>(Identifier.of(KuKirinMod.MOD_ID, "input"));

	public static final PacketCodec<RegistryByteBuf, KuKirinInputPayload> CODEC = PacketCodec.tuple(
			PacketCodecs.BOOL, KuKirinInputPayload::wheelie,
			PacketCodecs.BOOL, KuKirinInputPayload::nitro,
			PacketCodecs.BOOL, KuKirinInputPayload::horn,
			PacketCodecs.FLOAT, KuKirinInputPayload::crashSpeed,
			KuKirinInputPayload::new);

	@Override
	public CustomPayload.Id<? extends CustomPayload> getId() {
		return ID;
	}
}
