package com.kukirin.item;

import com.kukirin.KuKirinMod;
import com.kukirin.entity.ModEntities;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class ModItems {

	// ---- materiał kasku
	private static Map<ArmorItem.Type, Integer> defense() {
		Map<ArmorItem.Type, Integer> m = new EnumMap<>(ArmorItem.Type.class);
		m.put(ArmorItem.Type.BOOTS, 1);
		m.put(ArmorItem.Type.LEGGINGS, 2);
		m.put(ArmorItem.Type.CHESTPLATE, 3);
		m.put(ArmorItem.Type.HELMET, 3);
		m.put(ArmorItem.Type.BODY, 3);
		return m;
	}

	public static final RegistryEntry<ArmorMaterial> CARBON_MATERIAL = Registry.registerReference(
			Registries.ARMOR_MATERIAL,
			Identifier.of(KuKirinMod.MOD_ID, "kukirin_carbon"),
			new ArmorMaterial(
					defense(),
					15,
					SoundEvents.ITEM_ARMOR_EQUIP_NETHERITE,
					() -> Ingredient.ofItems(Items.IRON_INGOT),
					List.of(new ArmorMaterial.Layer(Identifier.of(KuKirinMod.MOD_ID, "kukirin_carbon"))),
					2.0f,
					0.1f));

	// ---- napój: Speed III (amp. 2) + Haste II (amp. 1), 45 s
	private static final FoodComponent EASY_BOOST_FOOD = new FoodComponent.Builder()
			.nutrition(2)
			.saturationModifier(0.3f)
			.alwaysEdible()
			.statusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 45, 2), 1.0f)
			.statusEffect(new StatusEffectInstance(StatusEffects.HASTE, 20 * 45, 1), 1.0f)
			.build();

	// ---- przedmioty
	public static final Item G2 = register("kukirin_g2_pro",
			new KuKirinScooterItem(() -> ModEntities.G2, new Item.Settings().maxCount(1)));

	public static final Item G4 = register("kukirin_g4_ultra_max",
			new KuKirinScooterItem(() -> ModEntities.G4, new Item.Settings().maxCount(1)));

	public static final Item EASY_BOOST = register("easy_boost_can",
			new EasyBoostItem(new Item.Settings().maxCount(16).food(EASY_BOOST_FOOD)));

	public static final Item HELMET = register("kukirin_full_face_carbon",
			new ArmorItem(CARBON_MATERIAL, ArmorItem.Type.HELMET,
					new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(37))));

	private static <T extends Item> T register(String name, T item) {
		return Registry.register(Registries.ITEM, Identifier.of(KuKirinMod.MOD_ID, name), item);
	}

	public static void init() {}

	private ModItems() {}
}
