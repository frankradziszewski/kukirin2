package com.kukirin.item;

import com.kukirin.entity.KuKirinEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

import java.util.List;

/**
 * Puszka Easy Boost. Efekty (Speed III + Haste II) daje FoodComponent zdefiniowany w ModItems,
 * a tutaj dodatkowo natychmiast ładujemy nitro hulajnogi (tej, na której jedziesz, lub najbliższej w promieniu 6 bloków).
 */
public class EasyBoostItem extends Item {
	public EasyBoostItem(Settings settings) {
		super(settings);
	}

	@Override
	public UseAction getUseAction(ItemStack stack) {
		return UseAction.DRINK;
	}

	@Override
	public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
		if (!world.isClient) {
			KuKirinEntity scooter = null;
			if (user.getVehicle() instanceof KuKirinEntity ridden) {
				scooter = ridden;
			} else {
				List<KuKirinEntity> near = world.getEntitiesByClass(KuKirinEntity.class, user.getBoundingBox().expand(6.0), e -> true);
				double best = Double.MAX_VALUE;
				for (KuKirinEntity e : near) {
					double d = e.squaredDistanceTo(user);
					if (d < best) { best = d; scooter = e; }
				}
			}
			if (scooter != null) {
				scooter.chargeNitro();
				if (user instanceof PlayerEntity player) {
					player.sendMessage(Text.translatable("message.kukirin.nitro_charged"), true);
				}
			}
		}
		return super.finishUsing(stack, world, user); // nakłada efekty i zużywa puszkę
	}
}
