package com.kukirin.item;

import com.kukirin.entity.KuKirinEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.function.Supplier;

/** Item stawiający hulajnogę na klikniętym bloku. */
public class KuKirinScooterItem extends Item {
	private final Supplier<EntityType<KuKirinEntity>> type;

	public KuKirinScooterItem(Supplier<EntityType<KuKirinEntity>> type, Settings settings) {
		super(settings);
		this.type = type;
	}

	@Override
	public ActionResult useOnBlock(ItemUsageContext ctx) {
		World world = ctx.getWorld();
		if (!(world instanceof ServerWorld serverWorld)) return ActionResult.SUCCESS;

		BlockPos pos = ctx.getBlockPos().offset(ctx.getSide());
		KuKirinEntity scooter = type.get().create(serverWorld);
		if (scooter == null) return ActionResult.FAIL;

		scooter.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, ctx.getPlayerYaw(), 0f);
		serverWorld.spawnEntity(scooter);
		ctx.getStack().decrementUnlessCreative(1, ctx.getPlayer());
		return ActionResult.CONSUME;
	}
}
