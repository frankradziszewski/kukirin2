package com.kukirin.item;

import com.kukirin.KuKirinMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItemGroups {
	public static final ItemGroup MAIN = Registry.register(
			Registries.ITEM_GROUP,
			Identifier.of(KuKirinMod.MOD_ID, "main"),
			FabricItemGroup.builder()
					.displayName(Text.translatable("itemGroup.kukirin.main"))
					.icon(() -> new ItemStack(ModItems.G4))
					.entries((context, entries) -> {
						entries.add(ModItems.G2);
						entries.add(ModItems.G4);
						entries.add(ModItems.EASY_BOOST);
						entries.add(ModItems.HELMET);
					})
					.build());

	public static void init() {}

	private ModItemGroups() {}
}
