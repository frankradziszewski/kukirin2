package com.kukirin.sound;

import com.kukirin.KuKirinMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public final class ModSounds {
	public static final SoundEvent ENGINE = register("scooter.engine");
	public static final SoundEvent HORN = register("scooter.horn");
	public static final SoundEvent NITRO = register("scooter.nitro");

	private static SoundEvent register(String name) {
		Identifier id = Identifier.of(KuKirinMod.MOD_ID, name);
		return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
	}

	public static void init() {}

	private ModSounds() {}
}
