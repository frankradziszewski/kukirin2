package com.kukirin;

import com.kukirin.client.KuKirinClientInput;
import com.kukirin.client.KuKirinEntityRenderer;
import com.kukirin.client.KuKirinModel;
import com.kukirin.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class KuKirinClientMod implements ClientModInitializer {
	public static final EntityModelLayer SCOOTER_LAYER =
			new EntityModelLayer(Identifier.of(KuKirinMod.MOD_ID, "scooter"), "main");

	@Override
	public void onInitializeClient() {
		EntityModelLayerRegistry.registerModelLayer(SCOOTER_LAYER, KuKirinModel::getTexturedModelData);
		EntityRendererRegistry.register(ModEntities.G2, KuKirinEntityRenderer::new);
		EntityRendererRegistry.register(ModEntities.G4, KuKirinEntityRenderer::new);
		KuKirinClientInput.init();
	}
}
