package com.kukirin;

import com.kukirin.entity.KuKirinEntity;
import com.kukirin.entity.ModEntities;
import com.kukirin.item.ModItemGroups;
import com.kukirin.item.ModItems;
import com.kukirin.network.KuKirinInputPayload;
import com.kukirin.sound.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.item.ItemStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class KuKirinMod implements ModInitializer {
	public static final String MOD_ID = "kukirin";
	public static final Logger LOGGER = LoggerFactory.getLogger("KuKirin Mod");

	@Override
	public void onInitialize() {
		// Kolejność ma znaczenie: dźwięki -> encje -> przedmioty -> zakładka kreatywna
		ModSounds.init();
		ModEntities.init();
		ModItems.init();
		ModItemGroups.init();

		// Pakiet klient -> serwer ze stanem sterowania (wheelie / nitro / klakson / zderzenie)
		PayloadTypeRegistry.playC2S().register(KuKirinInputPayload.ID, KuKirinInputPayload.CODEC);
		ServerPlayNetworking.registerGlobalReceiver(KuKirinInputPayload.ID, (payload, context) -> {
			var player = context.player();
			if (player.getVehicle() instanceof KuKirinEntity scooter && scooter.getControllingPassenger() == player) {
				scooter.applyClientInput(payload, player);
			}
		});

		// Kask Full-Face Carbon: całkowita ochrona przed upadkiem i uderzeniem w ścianę (kosztem wytrzymałości kasku)
		ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
			boolean crashLike = source.isOf(DamageTypes.FALL) || source.isOf(DamageTypes.FLY_INTO_WALL);
			if (!crashLike || amount <= 0f) return true;
			ItemStack helmet = entity.getEquippedStack(EquipmentSlot.HEAD);
			if (!helmet.isOf(ModItems.HELMET)) return true;
			helmet.damage(Math.max(1, (int) (amount / 4f)), entity, EquipmentSlot.HEAD);
			return false; // anuluj obrażenia
		});

		LOGGER.info("KuKirin Mod załadowany - pora na jazdę!");
	}
}
